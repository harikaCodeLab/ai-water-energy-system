import shutil

def upload_file():
    shutil.copy("data/usage.csv", "storage/usage.csv")
    return "✅ Uploaded successfully"

def download_file():
    shutil.copy("storage/usage.csv", "data/downloaded_usage.csv")
    return "✅ Downloaded successfully"